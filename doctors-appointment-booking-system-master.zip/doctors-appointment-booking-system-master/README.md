# doctors-appointment-booking-system

This is the first video for the tutorial building doctor's appointment booking system.
Using NodeJS and MySQL, the main feature in the website are:
- CRUD users, login, making medical appointments.
- Searching with ElasticSearch
- Chat bot Messenger Facebook (enhance with WitAI)

Backend: Nodejs (Express Framework), MySQL (Sequelize package)...
Frontend: EJS view engine, SASS, AJAX...

Playlist full tutorial: https://www.youtube.com/watch?v=25PzpAdndSs&list=PLNOjHC_BXrfBvYQVOfgUcKmWHK25SsPc6

### Find me here:
- Youtube Channel: https://bit.ly/subscribe-haryphamdev
- Facebook Fanpage: https://facebook.com/haryphamdev
- Patreon: https://www.patreon.com/haryphamdev
- Twitter: https://twitter.com/haryphamdev
- GitHub: https://github.com/haryphamdev
